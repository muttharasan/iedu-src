import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClassDetailsService {
  data = [{
    id: 1,
    classDetails: '1',
    sessionDetails: 'A',
    noOfStudents: '40',
    classIncharge: 'John',
    isActive: 'Y',
  }, {
      id: 1,
      classDetails: '1',
      sessionDetails: 'B',
      noOfStudents: '38',
      classIncharge: 'Predeep',
      isActive: 'Y',
    } ]
  constructor() { }

  getData() {
    return this.data;
  }
}
