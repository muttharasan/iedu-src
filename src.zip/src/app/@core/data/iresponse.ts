export class Iresponse {
  public statusCode: number;
  public data: string;
  public msg: string;
  constructor(statusCode: number, data: string, msg: string) {
    this.statusCode = statusCode;
    this.data = data;
    this.msg = msg;
}
}
