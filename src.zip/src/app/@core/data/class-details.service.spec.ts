import { TestBed, inject } from '@angular/core/testing';

import { ClassDetailsService } from './class-details.service';

describe('ClassDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClassDetailsService]
    });
  });

  it('should be created', inject([ClassDetailsService], (service: ClassDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
