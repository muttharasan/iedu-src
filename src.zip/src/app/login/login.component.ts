import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
 // template: '<p>Login works</p>',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) {
    console.log("Login working")
  }
  model = new user("", "");
  ngOnInit() {
  }

  newlogin() {
    var userName = this.model.username;
    var password = this.model.password;
    console.log(userName, password);
    if (userName == 'admin' && password == 'admin') {
      //  this.userService.setUserLoggedIn();
      this.router.navigate(['pages'])
    } else {
      window.confirm('Invalid UserName or Password');
    }
    
   // this.router.navigate(['pages'])
  }

}

export class user {

  constructor(
    public username: string,
    public password: string ) { }
}


