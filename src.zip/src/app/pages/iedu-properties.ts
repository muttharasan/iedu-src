import { identifierModuleUrl } from "@angular/compiler";

export class ieduUrl{

  // public  appurl ="http://localhost:8080/";
   public  appurl ="http://18.191.152.113:8080/iedu/";
   

   getappurl(){
       return this.appurl;
   }
}