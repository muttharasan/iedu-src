import { Component } from '@angular/core';
import { Student } from '../student';
import { Http, Headers, RequestOptions } from '@angular/http';
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import 'style-loader!angular2-toaster/toaster.css';
import { Iresponse } from '../../../@core/data/iresponse';
import { ieduUrl } from '../../iedu-properties';


@Component({
  selector: 'ngx-form-inputs',
  styleUrls: ['./form-inputs.component.scss'],
  templateUrl: './form-inputs.component.html',
})
export class FormInputsComponent {
// urlPrf = 'http://18.188.34.252/iedu/';
ieduUrlObj = new ieduUrl();
 urlPrf = this.ieduUrlObj.getappurl();

  classDetails = ['PRE-KG', 'LKG', 'UKG', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'Teacher'];
  public loading = false;
  model = new Student('', '', '', '', '', '', '', '');
  constructor(private http: Http, private toasterService: ToasterService) {


  }
  submitted = false;
  config: ToasterConfig;

  position = 'toast-top-right';
  animationType = 'fade';
  title = 'HI there!';
  content = `I'm cool toaster!`;
  timeout = 5000;
  toastsLimit = 5;
  type = 'default';

  isNewestOnTop = true;
  isHideOnClick = true;
  isDuplicatesPrevented = false;
  isCloseButton = true;

  private showToast(type: string, title: string, body: string) {
    this.config = new ToasterConfig({
      positionClass: this.position,
      timeout: this.timeout,
      newestOnTop: this.isNewestOnTop,
      tapToDismiss: this.isHideOnClick,
      preventDuplicates: this.isDuplicatesPrevented,
      animation: this.animationType,
      limit: this.toastsLimit,
    });
    const toast: Toast = {
      type: type,
      title: title,
      body: body,
      timeout: this.timeout,
      showCloseButton: this.isCloseButton,
      bodyOutputType: BodyOutputType.TrustedHtml,
    };
    this.toasterService.popAsync(toast);
  }

  onSubmit() { this.submitted = true; }
  get diagnostic() {

    return JSON.stringify(this.model);
  }
  /*
  newStudent() {

    var rollNo = this.model.student_RollNo;
    var name = this.model.student_name;
    var student_class = this.model.student_class;
    var student_session = this.model.student_session;
    var student_contact_no = this.model.student_contact_no;
    var student_gender = this.model.student_gender;
    console.log(JSON.stringify(this.model));

    const headers = new Headers();
    headers.append('Content-Type', 'application/json');

    this.showToast('Default', 'Students Details', 'Details Loaded successfully');
    const options = new RequestOptions({ headers: headers });
    this.http.post('http://localhost:8080/addStudents', JSON.stringify(this.model), options)
      .subscribe(res => console.log(res.json()));

  }
  */
  model1 = new Student('', '', '', '', '', '', '', '');
  file: File;
  onChange(event: EventTarget) {
    let eventObj: MSInputMethodContext = <MSInputMethodContext>event;
    let target: HTMLInputElement = <HTMLInputElement>eventObj.target;
    let files: FileList = target.files;
    this.file = files[0];
    
  }


  formData: FormData = new FormData();

  doAnythingWithFile() {
    const headers = new Headers();
    console.log(this.model1.student_class);
    console.log(this.model1.student_session);
    if (this.model1.student_session != '' && this.model1.student_class != '' && this.file.name != '') {
      this.formData.append('file', this.file, this.file.name);
      this.loading = true;
      this.http.post(this.urlPrf + 'upload/' + this.model1.student_class + '/' + this.model1.student_session,
        this.formData, {
          headers: headers,
        })
        .subscribe(response => {
          console.log("[upload][Status]-->" + response.json().statusCode);
          console.log("[upload][Message]-->" + response.json().data);
          this.showToast('Default', 'Upload Student Details', response.json().msg);
          this.model1 = new Student('', '', '', '', '', '', '', '');
          this.loading = false;
          this.file = null;
          this.sessionDetails1 = null;
        }
        , err => {
          this.loading = false;
          this.showToast('error', 'Message Details', err);
        }
      );
    }
    else {
    this.showToast('error', 'Student Details', 'Please Fill all the Details Or Refresh the Page and Try Again');
    }
  }
  gender;
  sessionDetails;
  urlSection;
    section() {
      console.log("inside session %o, ");
      this.urlSection = this.urlPrf + "getsection/" + this.model.student_class;
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.loading = true;
      this.http.get(this.urlSection, options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().data);
          this.sessionDetails = JSON.parse(response.json().data);
          this.loading = false;
          this.gender = ['Male', 'Female'];
        }, err => {
          this.loading = false;
          this.showToast('error', 'Message Details', err);
        });
    
  }
  sessionDetails1;
  section1() {
    console.log("inside session %o, ");
    this.urlSection = this.urlPrf+ "getsection/" + this.model1.student_class;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    this.loading = true;
    let options = new RequestOptions({ headers: headers });
    this.http.get(this.urlSection, options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.loading = false;
        this.sessionDetails1 = JSON.parse(response.json().data);
      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      });


  }
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  serviceUrl = this.urlPrf+'addStudents';
  newStudent() {
    console.log("[_callService][Start][URL]-->" + this.serviceUrl);
    if (this.model.student_session != '' && this.model.student_RollNo != '' && this.model.student_name != '' &&
      this.model.student_contact_no != '') {
      let headers = new Headers();
      this.loading = true;
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.http.post(this.serviceUrl, JSON.stringify(this.model), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().msg);
          this.showToast(this.type, 'Student Details', response.json().msg);
          this.sessionDetails = null;
          this.loading = false;
          this.model = new Student('', '', '', '', '', '', '', '');
        }, err => {
          this.loading = false;
          this.showToast('error', 'Message Details', err);
        }
        );
    }
    else {
      this.showToast('error', 'Student Details', 'Please Fill all the Details Or Refresh the Page and Try Again');
    }
  }

}
