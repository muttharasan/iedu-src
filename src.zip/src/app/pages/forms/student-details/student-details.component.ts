import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
//import { ServerDataSource } from 'ng2-smart-table';
import { LocalDataSource } from 'ng2-smart-table';
import { Http, Headers, RequestOptions } from '@angular/http';
 //ServerDataSource
import { SmartTableService } from '../../../@core/data/smart-table.service';
import { Student } from '../student';

import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import 'style-loader!angular2-toaster/toaster.css';
import { DomSanitizer } from '@angular/platform-browser';
import { StudentId_Name_msg } from './student-msg-service';
import { ieduUrl } from '../../iedu-properties';



@Component({
  selector: 'student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.scss']
})
export class StudentDetailsComponent implements OnInit {
  classDetails = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  classDetail = new classdetails(this.classDetails, this.classDetails);
  gender = ['Male', 'Female'];
  public loading = false;
  public page;
  settings = {
    actions: {
      add: false
    },
    pager: {
      perPage: 30
    },
    edit: {
      confirmSave: true,
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"(click)="save()"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    selectMode: 'multi',
    columns: {
      
      student_RollNo: {
        title: 'Student-RollNo',
        editable: false,
      },
      student_name: {
        title: 'Name',
      },
      student_class: {
        title: 'Class',
        editable: false,
        filter: {
          type: 'list',
          config: {
            selectText: 'class',
            list: [
              { value: 'PRE-KG', title: 'PRE-KG' },
              { value: 'LKG', title: 'LKG' },
              { value: 'UKG', title: 'UKG' },
              { value: 'I', title: 'I' },
              { value: 'II', title: 'II' },
              { value: 'III', title: 'III' },
              { value: 'IV', title: 'IV' },
              { value: 'V', title: 'V' },
              { value: 'VI', title: 'VI' },
              { value: 'VII', title: 'VII' },
              { value: 'VIII', title: 'VIII' },
              { value: 'IX', title: 'IX' },
              { value: 'X', title: 'X' },
              { value: 'Teacher', title: 'Teacher' },
            ],
          },
        },
        filterFunction(cell: any, search?: string): boolean {
          if(cell == search){
          return cell;
          }

        },

      },
      student_session: {
        title: 'Section',
        editable: false,
      },
      student_contact_no: {
        title: 'Phone No',
        type: 'html',
      },
      student_gender: {
        title: 'Gender',
        filter: {
          type: 'list',
          config: {
            selectText: 'Select',
            list: [
              { value: 'Male', title: 'Male' },
              { value: 'Female', title: 'Female' },
            ],
          },
        },
         editor: {
           type: 'list',
           config: {
             selectText: 'Select',
             list: [
               { value: 'Male', title: 'Male' },
               { value: 'Female', title: 'Female' },
             ],
           },

        }
      },
    },
  };

  settingsSelected = {
    actions: {
      add: false,
      edit: false,
      delete:false
    },
    pager: {
      display: false
    },
    columns: {
      student_RollNo: {
        title: 'ID',
        editable: false,

        filter: false
      }
    },
  };

  sourceSelected: LocalDataSource = new LocalDataSource();

 // source: ServerDataSource;
//url = 'http://localhost:8080/';
 //url = 'http://18.188.34.252/iedu/';
 ieduUrlObj = new ieduUrl();
 url = this.ieduUrlObj.getappurl();
  source: LocalDataSource = new LocalDataSource();
  constructor(private service: SmartTableService, private http: Http, private toasterService: ToasterService,
    private location: Location) {
    this.loading = true;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    this.http.get(this.url+'getAll', options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.source.load(JSON.parse(response.json().data));
        this.loading = false;

      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      }
      );
  }

  config: ToasterConfig;

  position = 'toast-top-right';
  animationType = 'fade';
  title = 'HI there!';
  content = `I'm cool toaster!`;
  timeout = 5000;
  toastsLimit = 5;
  type = 'default';

  isNewestOnTop = true;
  isHideOnClick = true;
  isDuplicatesPrevented = false;
  isCloseButton = true;

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  private showToast(type: string, title: string, body: string) {

    this.config = new ToasterConfig({
      positionClass: this.position,
      timeout: this.timeout,
      newestOnTop: this.isNewestOnTop,
      tapToDismiss: this.isHideOnClick,
      preventDuplicates: this.isDuplicatesPrevented,
      animation: this.animationType,
      limit: this.toastsLimit,
    });
    const toast: Toast = {
      type: type,
      title: title,
      body: body,
      timeout: this.timeout,
      showCloseButton: this.isCloseButton,
      bodyOutputType: BodyOutputType.TrustedHtml,
    };
    this.toasterService.popAsync(toast);
  }

  serviceUrlDelete = this.url+'deleteStudent';
  onDeleteConfirm(event): void {
    console.log('On delete event');
    if (window.confirm('Are you sure you want to delete?')) {
      console.log(event);
      console.log(JSON.stringify(event.data));
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.http.post(this.serviceUrlDelete, JSON.stringify(event.data), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().msg);
          this.showToast('error', 'Delete Student Details', response.json().data);
          event.confirm.resolve();
        }
        );

    } else {
      event.confirm.reject();
    }
  }

  selectedStudentDetais: Student[];
  selectedStudentDetaistemp = [];
   c = [];
   studentId_name_msgObj= new StudentId_Name_msg(this.c,'');

  deleteList(name) {
    console.log(name);
    const index: number = this.c.indexOf(name);

    this.c.splice(index, 1);

    console.log(this.c);
  }
   map = new Map();
  rowClicked(event) {
    console.log(event.selected);
    console.log(JSON.stringify(event.selected));
    this.selectedStudentDetais = event.selected;
   // this.selectedStudentDetaistemp = event.selected;
   // this.selectedStudentDetais.push((JSON.parse(JSON.stringify(event.selected))));
    /*this.selectedStudentDetais.map(item => {
      this.selectedStudentDetaistemp.push(item.student_RollNo);
    });*/
    this.selectedStudentDetais.map(item => {
      return {
        student_RollNo:  item.student_id+'-' +item.student_RollNo +'-'+item.student_name ,
        student_name: item.student_name,
        student_contact_no: item.student_contact_no
      } 
    }).forEach(item => this.selectedStudentDetaistemp.push(item));
    this.c = this.removeDuplicateUsingSet(this.selectedStudentDetaistemp);
    this.studentId_name_msgObj.student_id_name =this.c;
    console.log('Slected student' + this.c);

 
  }
  removeDuplicateUsingSet(arr) {
    let unique_array = Array.from(new Set(arr.map(item => (item.student_RollNo))));
  return unique_array
  }
  deleteListClearAll() {
    this.c.length = 0;
    
    this.selectedStudentDetais.length = 0;

    this.selectedStudentDetaistemp.length=0;
  }
  serviceUrl;
  message :string="";
  sendMsg() {
    this.serviceUrl = this.url + 'sendMessageSelected';
    console.log("[_callService][Start][URL]-->" + this.serviceUrl);
    console.log("[_callService][students]-->" + this.selectedStudentDetais);
    console.log("[_callService][message]-->" + this.message);
   
    if (this.c .length != 0 && this.message != '') {
      this.studentId_name_msgObj.student_msg = this.message;
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.loading = true;
      this.http.post(this.serviceUrl, (JSON.stringify( this.studentId_name_msgObj)) , options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().data);
          this.showToast(this.type, 'Message Details', response.json().msg);
          this.loading = false;
          //this.message = '';
          this.c.length = 0;

          this.selectedStudentDetais.length = 0;

          this.selectedStudentDetaistemp.length = 0;
          
        }, err => {
          this.loading = false;
          this.showToast('error', 'Message Details', err);
        }
        );
    } else {
      this.showToast('error', 'Send SMS Selected', 'Please select students Or Fill the message');
    }
  }
  serviceUrlUpdate = this.url+'updateStudent';
  onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.newData['name'] += ' + added in code';
      console.log(event.newData.student_name);
      console.log(JSON.stringify(event.newData));

      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.http.post(this.serviceUrlUpdate, JSON.stringify(event.newData), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          if (response.json().statusCode == '200') {
            console.log("[_callService][Message]-->" + response.json().msg);
            this.showToast('success', 'Update Student Details', response.json().data);
            event.confirm.resolve(event.newData);
          }
          else {
            this.showToast('error', 'Update Student Details', response.json().data);
          }
        }
        );

    } else {
      event.confirm.reject();
    }
  }
  serviceUrlNew = 'http://18.188.34.252/iedu/dele';
  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve(event.newData);

    } else {
      event.confirm.reject();
    }
  }
  
  ngOnInit() {
    this.page = 20;
  }

}

export class classdetails {


  constructor(
    public value: string[],
    public title: string[]
  ) { }


}
