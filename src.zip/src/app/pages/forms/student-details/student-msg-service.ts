export class StudentId_Name_msg {
 

    constructor(
      public student_id_name :any[],
        public student_msg: string
    ) { }
  
  
  }
  