export class Student {
 

  constructor(
    public student_id: string,
    public student_RollNo: string,
    public student_name: string,
    public student_class: string,
    public student_session: string,
    public student_contact_no?: string,
    public student_gender?: string,
    public student_isactive?: string,
    public student_msg?: string
  ) { }


}
