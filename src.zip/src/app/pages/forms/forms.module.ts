import { NgModule } from '@angular/core';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { ToasterModule } from 'angular2-toaster';

import { ThemeModule } from '../../@theme/theme.module';
import { FormsRoutingModule, routedComponents } from './forms-routing.module';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { LoadingModule } from 'ngx-loading';
import { DomSanitizer } from '@angular/platform-browser';
import { MatListModule } from '@angular/material/list';


@NgModule({
  imports: [
    ThemeModule,
    FormsRoutingModule,
    Ng2SmartTableModule, HttpModule, ToasterModule, LoadingModule, MatListModule, 
  ],
  declarations: [
    ...routedComponents,
    StudentDetailsComponent,
  ],
})
export class FormsModule { }
