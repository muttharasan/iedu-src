import { Component } from '@angular/core';
import { Student } from '../student';
import { Http, Headers, RequestOptions } from '@angular/http';
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import 'style-loader!angular2-toaster/toaster.css';
import { Iresponse } from '../../../@core/data/iresponse';
import { ieduUrl } from '../../iedu-properties';

@Component({
  selector: 'ngx-form-layouts',
  styleUrls: ['./form-layouts.component.scss'],
  templateUrl: './form-layouts.component.html',
})
export class FormLayoutsComponent {
  classDetails = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  model = new Student('', '', '', '', '', '', '','','');
  model1 = new Student('', '', '', '', '', '', '','','');
  model2 = new Student('', '', '', '', '', '', '','','');
//urlPref = 'http://18.188.34.252/iedu/';
  //urlPref = 'http://localhost:8080/';
  ieduUrlObj = new ieduUrl();
  urlPref = this.ieduUrlObj.getappurl();
  public loading = false;
  constructor(private http: Http, private toasterService: ToasterService) {


  }
  submitted = false;
  config: ToasterConfig;

  position = 'toast-top-right';
  animationType = 'fade';
  title = 'HI there!';
  content = `I'm cool toaster!`;
  timeout = 5000;
  toastsLimit = 5;
  type = 'default';

  isNewestOnTop = true;
  isHideOnClick = true;
  isDuplicatesPrevented = false;
  isCloseButton = true;

  private showToast(type: string, title: string, body: string) {
    this.config = new ToasterConfig({
      positionClass: this.position,
      timeout: this.timeout,
      newestOnTop: this.isNewestOnTop,
      tapToDismiss: this.isHideOnClick,
      preventDuplicates: this.isDuplicatesPrevented,
      animation: this.animationType,
      limit: this.toastsLimit,
    });
    const toast: Toast = {
      type: type,
      title: title,
      body: body,
      timeout: this.timeout,
      showCloseButton: this.isCloseButton,
      bodyOutputType: BodyOutputType.TrustedHtml,
    };
    this.toasterService.popAsync(toast);
  }
  message;
  serviceUrl;
  sendMsg() {
    this.serviceUrl = this.urlPref+'sendMessageClassSection';
    console.log("[_callService][Start][URL]-->" + this.serviceUrl);
    console.log("[_callService][Status]-->" + this.message);
    let msg =this.model1.student_msg;
   if (this.model.student_class != '' && this.model.student_session != '' && this.model.student_msg!='') {

      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    this.loading = true;
      this.http.post(this.serviceUrl, JSON.stringify(this.model), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().data);
          this.showToast(this.type, 'Message Details', response.json().msg);
          this.loading = false;
          this.model = new Student('', '', '', '', '', '', '','',msg);
          this.sessionDetails = null;
        }, err => {
          this.loading = false;
          this.showToast('error', 'Message Details', err);
        }
        );
   } else {
     this.showToast('error', 'Student Details', 'Please Fill all the Details');
    }
  }
 
  sessionDetails;
  urlSection;
  section() {
    console.log("inside session %o, ");
    this.urlSection= this.urlPref+ "getsection/" + this.model.student_class;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    this.loading = true;
    this.http.get(this.urlSection, options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.loading = false;
        this.sessionDetails = JSON.parse(response.json().data);
      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      });

  }

  
  serviceUrl1;
  sendMsg1() {
    this.serviceUrl1 =this.urlPref+ 'sendMessageIndi';
    console.log("[_callService][Start][URL]-->" + this.serviceUrl1);
    console.log(this.model1)
    
    if (this.model1.student_class != '' && this.model1.student_session != ''
      && this.model1.student_RollNo != '' && this.model1.student_msg != '') {

    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    this.loading = true;
    let msg =this.model1.student_msg;
    this.http.post(this.serviceUrl1, JSON.stringify(this.model1), options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.showToast(this.type, 'Message Details', response.json().msg);
        this.model1 = new Student('', '', '', '', '', '', '','',msg);
        this.loading = false;
        this.sessionDetails1 = null;
      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      }
      );
    } else {
       this.showToast('error', 'Student Details', 'Please Fill all the Details');
     }
  }

  sessionDetails1;
  urlSection1;
  section1() {
    console.log("inside session %o, " + this.model1.student_class);
    this.urlSection1 = this.urlPref+"getsection/" + this.model1.student_class;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    this.loading = true;
    this.http.get(this.urlSection1, options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.sessionDetails1 = JSON.parse(response.json().data);
        this.loading = false;
      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      });

  }


  serviceUrl2;
  sendMsg2() {
    this.serviceUrl2 = this.urlPref+'sendMessageall';
    console.log("[_callService][Start][URL]-->" + this.serviceUrl2);

    if (this.model2.student_msg != '') {

    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.loading = true;
    this.http.post(this.serviceUrl2,JSON.stringify(this.model2), options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        this.showToast(this.type, 'Message Details', response.json().msg);
        this.loading = false;
        this.model2 = new Student('', '', '', '', '', '', '');
      }, err => {
        this.loading = false;
        this.showToast('error', 'Message Details', err);
      }
      );
    } else {
      this.showToast('error', 'Student Details', 'Please Fill all the Message');
    }
  }
}
