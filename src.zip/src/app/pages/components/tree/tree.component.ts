import { Component } from '@angular/core';
import { TreeModel } from 'ng2-tree';
import { LocalDataSource } from 'ng2-smart-table';
//import { ServerDataSource } from 'ng2-smart-table';
import { Http , Headers, RequestOptions } from '@angular/http';
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import 'style-loader!angular2-toaster/toaster.css';

import { ClassDetailsService } from '../../../@core/data/class-details.service';
import { ieduUrl } from '../../iedu-properties';

@Component({
  selector: 'ngx-tree',
  templateUrl: './tree.component.html',
})
export class TreeComponent {

  settings = {
    actions: {
      add: false
    },
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,

    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
     classDetails: {
        title: 'Class',
        type: 'string',
        editable: false,
      },
      sessionDetails: {
        title: 'Section',
        type: 'string',
        editable: false,
      },
      noOfStudents: {
        title: 'Number of Students',
        type: 'number',
      },
      classIncharge: {
        title: 'Class-Incharge',
        type: 'string',
      },
      isActive: {
        title: 'Is-Active',
        type: 'string',
        editor: {
          type: 'list',
          config: {
            selectText: 'Select',
            list: [
              { value: 'Y', title: 'Y' },
              { value: 'N', title: 'N' },
            ],
          },
        }
      },
    },
  };
source: LocalDataSource = new LocalDataSource();
 //url = 'http://18.188.34.252/iedu/';
 //url = 'http://localhost:8080/';
 ieduUrlObj = new ieduUrl();
 url = this.ieduUrlObj.getappurl();
  constructor(private http: Http, private toasterService: ToasterService) {
   let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
    this.http.get(this.url + 'getAllClass', options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().statusCode);
        console.log("[_callService][Message]-->" + response.json().data);
        //this.showToast('error', 'Delete Student Details', response.json().msg);
        this.source.load(JSON.parse(response.json().data));
        
      }
      );
   // const data = this.service.getData();
   
  }
 /*
 source: ServerDataSource;
  constructor(private http: Http, private toasterService: ToasterService) {
   // this.service.getHeroes();
   // const data = this.service.getData();
    //this.source.load(data);
   // console.log(this.service.getHeroes());
    this.source = new ServerDataSource(http, { endPoint: 'http://localhost:8080/getAllClass' });
  }*/

  config: ToasterConfig;

  position = 'toast-top-right';
  animationType = 'fade';
  title = 'HI there!';
  content = `I'm cool toaster!`;
  timeout = 5000;
  toastsLimit = 5;
  type = 'default';

  isNewestOnTop = true;
  isHideOnClick = true;
  isDuplicatesPrevented = false;
  isCloseButton = true;

  private showToast(type: string, title: string, body: string) {
    this.config = new ToasterConfig({
      positionClass: this.position,
      timeout: this.timeout,
      newestOnTop: this.isNewestOnTop,
      tapToDismiss: this.isHideOnClick,
      preventDuplicates: this.isDuplicatesPrevented,
      animation: this.animationType,
      limit: this.toastsLimit,
    });
    const toast: Toast = {
      type: type,
      title: title,
      body: body,
      timeout: this.timeout,
      showCloseButton: this.isCloseButton,
      bodyOutputType: BodyOutputType.TrustedHtml,
    };
    this.toasterService.popAsync(toast);
  }

  serviceUrlDelete =this.url+ 'deleteClassDetails';
  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete Class and Student Details?')) {
      console.log(event);
      console.log(JSON.stringify(event.data));
      console.log("[_callService][Status]-->" +event.data);
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      this.http.post(this.serviceUrlDelete, JSON.stringify(event.data), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().msg);
          this.showToast('error', 'Delete Student Details', response.json().data);
          event.confirm.resolve();
        }
        );
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  serviceUrlUpdate = this.url+'updateClassDetails';
  onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.newData['name'] += ' + added in code';
      // console.log(event.newData.student_name);
      console.log(JSON.stringify(event.newData));
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      try { 
      this.http.post(this.serviceUrlUpdate, JSON.stringify(event.newData), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().msg);
          console.log(response.status)
          if (response.json().statusCode == 400) {
            this.showToast('error', 'Update Student Details', 'Please Enter Valid Data');
          }
          else {
          this.showToast('success', 'Update Student Details', response.json().data);
            event.confirm.resolve(event.newData);
          }
        }
        );
    }
    catch ( e){
        this.showToast('error', 'Update Student Details', 'Please Enter Valid Data');
    }
    } else {
      event.confirm.reject();
    }
  }
  serviceUrlNew = 'http://18.188.34.252/iedu/dele';
  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to delete?')) {

      event.confirm.resolve(event.newData);

    } else {
      event.confirm.reject();
    }
  }
}
