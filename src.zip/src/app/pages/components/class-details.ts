export class ClassDetailsBean {


  constructor(
    public id?: string,
    public classDetails?: string,
    public sessionDetails?: string,
    public noOfStudents?: string,
    public classIncharge?: string,
    public isActive?: string
  ) { }
}
