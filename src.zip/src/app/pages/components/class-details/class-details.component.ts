import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'class-details',
  templateUrl: './class-details.component.html',
  styleUrls: ['./class-details.component.scss']
})
export class ClassDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
