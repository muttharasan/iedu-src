import { NgModule } from '@angular/core';
import { Ng2SmartTableModule } from 'ng2-smart-table';

import { TreeModule } from 'ng2-tree';
import { ToasterModule } from 'angular2-toaster';

import { ThemeModule } from '../../@theme/theme.module';
import { ComponentsRoutingModule, routedComponents } from './components-routing.module';
import { ClassDetailsComponent } from './class-details/class-details.component';

@NgModule({
  imports: [
    ThemeModule,
    ComponentsRoutingModule,
    TreeModule,
    ToasterModule,
    Ng2SmartTableModule
  ],
  declarations: [
    ...routedComponents,
    ClassDetailsComponent,
  ],
})
export class ComponentsModule { }
