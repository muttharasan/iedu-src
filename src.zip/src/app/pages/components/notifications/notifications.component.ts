import { Component } from '@angular/core';
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import { ClassDetailsBean } from '../class-details';
import 'style-loader!angular2-toaster/toaster.css';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Iresponse } from '../../../@core/data/iresponse';
import { ieduUrl } from '../../iedu-properties';

@Component({
  selector: 'ngx-notifications',
  styleUrls: ['./notifications.component.scss'],
  templateUrl: './notifications.component.html',
})
export class NotificationsComponent {
  constructor(private toasterService: ToasterService, private http: Http) { }
  //urlPref = 'http://18.188.34.252/iedu/';
  //urlPref = 'http://localhost:8080/';
  ieduUrlObj = new ieduUrl();
  urlPref = this.ieduUrlObj.getappurl();
  config: ToasterConfig;

  position = 'toast-top-right';
  animationType = 'fade';
  title = 'HI there!';
  content = `I'm cool toaster!`;
  timeout = 5000;
  toastsLimit = 5;
  type = 'default';

  isNewestOnTop = true;
  isHideOnClick = true;
  isDuplicatesPrevented = false;
  isCloseButton = true;

  types: string[] = ['default', 'info', 'success', 'warning', 'error'];
  animations: string[] = ['fade', 'flyLeft', 'flyRight', 'slideDown', 'slideUp'];
  positions: string[] = ['toast-top-full-width', 'toast-bottom-full-width', 'toast-top-left', 'toast-top-center',
    'toast-top-right', 'toast-bottom-right', 'toast-bottom-center', 'toast-bottom-left', 'toast-center'];

  quotes = [
    { title: null, body: 'We rock at <i>Angular</i>' },
    { title: null, body: 'Titles are not always needed' },
    { title: null, body: 'Toastr rock!' },
    { title: 'What about nice html?', body: '<b>Sure you <em>can!</em></b>' },
  ];

  makeToast() {
    this.showToast(this.type, this.title, this.content);
  }

  openRandomToast() {
    const typeIndex = Math.floor(Math.random() * this.types.length);
    const quoteIndex = Math.floor(Math.random() * this.quotes.length);
    const type = this.types[typeIndex];
    const quote = this.quotes[quoteIndex];

    this.showToast(type, quote.title, quote.body);
  }

  private showToast(type: string, title: string, body: string) {
    this.config = new ToasterConfig({
      positionClass: this.position,
      timeout: this.timeout,
      newestOnTop: this.isNewestOnTop,
      tapToDismiss: this.isHideOnClick,
      preventDuplicates: this.isDuplicatesPrevented,
      animation: this.animationType,
      limit: this.toastsLimit,
    });
    const toast: Toast = {
      type: type,
      title: title,
      body: body,
      timeout: this.timeout,
      showCloseButton: this.isCloseButton,
      bodyOutputType: BodyOutputType.TrustedHtml,
    };
    this.toasterService.popAsync(toast);
  }

  clearToasts() {
    this.toasterService.clear();
  }
  model = new ClassDetailsBean('', '', '', '', '', 'Y');
  submitted = false;

  onSubmit() { this.submitted = true; }
  get diagnostic() {

    return JSON.stringify(this.model);
  }
  /*
  newClassDetails()Promise<Iresponse> {
  console.log(JSON.stringify(this.model));
    this.makeToast();
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');


    const options = new RequestOptions({ headers: headers });
   this.http.post('http://localhost:8080/addClassDetails', JSON.stringify(this.model), options)
      .subscribe(res => console.log(res.json()));

     = this.http.post('', JSON.stringify(this.model), options)
      .toPromise()
      .then(response => {
        console.log("[_callService][Status]-->" + response.json().status);
        console.log("[_callService][Message]-->" + response.json().message);
        return new Iresponse(response.json().status, response.json().data, response.json().message);
      }

  } */
  serviceUrl = this.urlPref+'addClassDetails';
  newClassDetails(): Promise<Iresponse> {
    console.log("[_callService][Start][URL]-->" + this.serviceUrl);
    if (this.model.classDetails != '' && this.model.noOfStudents != '' && this.model.sessionDetails != ''
      && this.model.classIncharge != '') {
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let options = new RequestOptions({ headers: headers });
      return this.http.post(this.serviceUrl, JSON.stringify(this.model), options)
        .toPromise()
        .then(response => {
          console.log("[_callService][Status]-->" + response.json().statusCode);
          console.log("[_callService][Message]-->" + response.json().msg);
          this.showToast(this.type, 'ClassDetails', response.json().data);
          this.model = new ClassDetailsBean('', '', '', '', '', 'Y');
          return new Iresponse(response.json().status, response.json().data, response.json().msg);
        }


        );
    } else {
      this.showToast('error', 'Class Details', 'Please Fill all the Details Or Refresh the Page and Try Again');
    }
  }
}
